public class DouglasFir extends Tree {
    public DouglasFir(){
        description = "Douglas Fir decorated with";
        cost = 15;
    }
    public double Cost(){
        return cost;
    }
}