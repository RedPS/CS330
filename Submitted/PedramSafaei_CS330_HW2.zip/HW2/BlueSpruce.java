public class BlueSpruce extends Tree {
    public BlueSpruce(){
        description = "Blue Spruce decorated with";
        cost = 20;
    }
    public double Cost(){
        return cost;
    }
}