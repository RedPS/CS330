public class BalsamFir extends Tree {
    public BalsamFir(){
        description = "Balsam Fir decorated with";
        cost = 5;
    }
    public double Cost(){
        return cost;
    }
}