public class FraserFir extends Tree {
    public FraserFir(){
        description = "FraserFir decorated with";
        cost = 12;
    }
    public double Cost(){
        return cost;
    }
}