public abstract class Decorations extends Tree {
    Tree tree;
    public abstract String printtree();
}