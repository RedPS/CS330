public class tankDefend implements orders{
    public void executeOrder(){
        System.out.print("Tank is defending ");
    }
}