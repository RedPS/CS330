//orders class 

public interface orders{
    public void executeOrder();
}