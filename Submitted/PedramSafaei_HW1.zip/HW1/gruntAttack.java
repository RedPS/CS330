public class gruntAttack implements orders{
    public void executeOrder(){
        System.out.print("Grunt is attacking ");
    }
}