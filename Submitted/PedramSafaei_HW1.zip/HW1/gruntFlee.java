public class gruntFlee implements orders{
    public void executeOrder(){
        System.out.print("Grunt is fleeing ");
    }
}