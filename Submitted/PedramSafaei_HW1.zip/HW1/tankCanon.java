public class tankCanon implements weapons{
    public void useWeapon(){
        System.out.println("Using the Canon");
    }
}