//weapons class
public interface weapons{
    public void useWeapon();
}
