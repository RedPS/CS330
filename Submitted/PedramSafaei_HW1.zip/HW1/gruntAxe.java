public class gruntAxe implements weapons{
    public void useWeapon(){
        System.out.println("Using the AXE");
    }
}