public class gruntPistol implements weapons{
    public void useWeapon(){
        System.out.println("Using the Pistol");
    }
}