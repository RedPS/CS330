public class tankAttack implements orders{
    public void executeOrder(){
        System.out.print("Tank is attacking ");
    }
}