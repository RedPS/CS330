public class tankSelfDestruct implements orders{
    public void executeOrder(){
        System.out.print("Tank is performing a self destruct ");
    }
}