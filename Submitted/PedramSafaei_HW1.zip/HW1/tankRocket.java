public class tankRocket implements weapons{
    public void useWeapon(){
        System.out.println("Using the Rocket");
    }
}